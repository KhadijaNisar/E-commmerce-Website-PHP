<?php
 require_once('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
 $db = new Database();
$id=$_GET['id'];
$tableName = "tblcategory";
$row="catId";
$res=$db->Delete($tableName,"catId = $id");
if($res){
    header('location:http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Categories/frmDisplayAll.php');
}
?>