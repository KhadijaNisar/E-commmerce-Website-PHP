<?php
include('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
$obj = new Database();

$param = [
    'catName' => $_POST['catName'],
    'catBrand' => $_POST['catBrand'],
    'productQty' => $_POST['noOfProducts'],
];
$id = $_POST['catId'];
$obj->Update('tblcategory', $param, "catId = $id");
header("Location: http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Categories/frmDisplayAll.php");
?>