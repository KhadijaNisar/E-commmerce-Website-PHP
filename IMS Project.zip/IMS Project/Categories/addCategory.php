<?php 
require_once('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
$db = new Database();
$array = [
    'catName' => $_POST['catname'],
    'catBrand' => $_POST['catbrand'],
    'productQty' => $_POST['noOfProducts'],
];
$db->Insert('tblcategory', $array);
header('Location: http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Categories/frmDisplayAll.php');
?>