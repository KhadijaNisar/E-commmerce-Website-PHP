<?php
require_once('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
$db = new Database();
$prodId = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Edit</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
          h2 {
            text-align: center;
            font-size: 30px;
            text-transform: uppercase;
            color: #222;
            letter-spacing: 1px;
            font-family: "Playfair Display", serif;
            font-weight: 300;
        }
        form {
            width: 500px;
            margin: 50px auto;

            padding: 30px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }

        input[type="submit"]:hover {
            background-color: #3E8E41;
        }



        .btn {
            font-family: Roboto, sans-serif;
            font-weight: 0;
            font-size: 14px;
            color: #fff;
            background-color: #0066CC;
            padding: 10px 30px;
            border: 2px solid #0066cc;
            box-shadow: rgba(14, 30, 37, 0.12) 0px 2px 4px 0px, rgba(14, 30, 37, 0.32) 0px 2px 16px 0px;
            border-radius: 50px;
            transition: 1000ms;
            transform: translateY(0);
            display: flex;
            flex-direction: row;
            align-items: center;
            cursor: pointer;
        }

        .btn:hover {

            transition: 1000ms;
            padding: 10px 50px;
            transform: translateY(-0px);
            background-color: #fff;
            color: #0066cc;
            border: solid 2px #0066cc;
        }
    </style>

</head>

<body>

    <div class="container">
        <form action="updateProduct.php" method="post">
            <h2>Update Product</h2>
            <?php
            $query = "SELECT * FROM tblproduct WHERE prodId = '$prodId'";
            $result = $db->sql($query);
            foreach ($result as $row) {
                ?>
                <div class="form-group">
                    <input type="hidden" class="form-control" id="prodId" name="prodId"
                        value="<?php echo $row['prodId'] ?>">
                </div>
                <div class="form-group">
                    <label for="name">Product Name:</label>
                    <input type="text" class="form-control" id="prodName" name="prodName"
                        value="<?php echo $row['prodName'] ?>">
                </div>
                <div class="form-group">
                    <label for="name">Product Category:</label>
                    <input type="text" class="form-control" id="prodCategory" name="prodCategory"
                        value="<?php echo $row['prodCatId'] ?>">
                </div>
                <div class="form-group">
                    <label for="name">Product Supplier:</label>
                    <input type="text" class="form-control" id="prodSupplier" name="prodSupplier"
                        value="<?php echo $row['prodSupId'] ?>">
                </div>
                <div class="form-group">
                    <label for="phone">Product Quantity:</label>
                    <input type="number" class="form-control" id="prodQty" value="<?php echo $row['prodQty'] ?>"
                        name="prodQty">
                </div>
                <div class="form-group">
                    <label for="phone">Product Description:</label>
                    <input type="text" class="form-control" id="prodDesc" value="<?php echo $row['prodDescription'] ?>"
                        name="prodDescription">
                </div>
                <div class="form-group">
                    <label for="phone">Product Unitprice:</label>
                    <input type="text" class="form-control" id="price" value="<?php echo $row['prodUnitPrice'] ?>"
                        name="prodUnitPrice">
                </div>
            <?php } ?>
            <button type="submit" class="btn btn-default btn-primary">Update</button>

    </form>
    </div>
</body>

</html>