<?php
include('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
$obj = new Database();

$param = [
    'supplierName' => $_POST['sname'],
    'supplierCompany' => $_POST['scompany'],
    'supplierPhone' => $_POST['sphone'],
];
$id = $_POST['sId'];
$obj->Update('tblsupplier', $param, "supplierId = $id");
header("Location: http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Suppliers/frmDisplayAll.php");
?>