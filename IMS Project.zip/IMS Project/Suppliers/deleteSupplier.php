<?php
 require_once('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
 $db = new Database();
$id=$_GET['id'];
$tableName = "tblSupplier";
$res=$db->Delete($tableName,"supplierId = $id");
if($res){
    header('location:http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Suppliers/frmDisplayAll.php');
}
?>