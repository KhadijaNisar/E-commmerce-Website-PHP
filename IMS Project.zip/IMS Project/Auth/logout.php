<?php
session_start();
session_destroy();
header('location:http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Auth/frmLogin.php');
exit();
?>