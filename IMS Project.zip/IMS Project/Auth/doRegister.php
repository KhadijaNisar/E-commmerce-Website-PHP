<?php
require_once('E:\xamp\htdocs\Practice\IMS Project\IMS Project\Database\database.php');
$db = new Database();
$array = [
    'userFullName' => $_POST['fname'],
    'userName' => $_POST['userName'],
    'userPass' => $_POST['pwd'],
    'userEmail' => $_POST['email'],
];
$result = $db->Insert('admin', $array);
if($result==1){
    header('location: http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Auth/frmLogin.php');
}else{
    header('location: http://localhost:8081/Practice/IMS%20Project/IMS%20Project/Auth/frmRegister.php');
}
?>